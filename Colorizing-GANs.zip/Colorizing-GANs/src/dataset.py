import glob
import numpy as np
import tensorflow as tf
from scipy.misc import imread, imresize
from abc import abstractmethod
from .utils import unpickle
import os 
import random
from sklearn.model_selection import train_test_split

DOG_DATASET = 'dog'
PLACES365_DATASET = 'places365'


class BaseDataset():
    def __init__(self, name, path, training=True, augment=True):
        self.name = name
        self.augment = augment and training
        self.training = training
        self.path = path
        self._data = []

    def __len__(self):
        return len(self.data)

    def __iter__(self):
        total = len(self)
        start = 0

        while start < total:
            item = self[start]
            start += 1
            yield item

        raise StopIteration

    def __getitem__(self, index):
        val = self.data[index]
        try:
            img = imread(val) if isinstance(val, str) else val

            if self.augment and np.random.binomial(1, 0.5) == 1:
                img = img[:, ::-1, :]

        except:
            img = None

        return img

    def generator(self, batch_size, recusrive=False):
        start = 0
        total = len(self)

        while True:
            while start < total:
                end = np.min([start + batch_size, total])
                items = []

                for ix in range(start, end):
                    item = self[ix]
                    if item is not None:
                        items.append(item)

                start = end
                yield np.array(items)

            if recusrive:
                start = 0

            else:
                raise StopIteration


    @property
    def data(self):
        if len(self._data) == 0:
            self._data = self.load()
            np.random.shuffle(self._data)

        return self._data

    @abstractmethod
    def load(self):
        return []


class DogDataset(BaseDataset):
    def __init__(self, path, training=True, augment=True):
        super(DogDataset, self).__init__(DOG_DATASET, path, training, augment)

    def load(self):
                
        if self.training:
            data = []
            for filename in glob.glob('Images/train/*.jpg'): 
                im = imread(filename)
                resized_image = imresize(im, (128, 128))
                if resized_image is not None:
                    data.append(resized_image)
            data = np.array(data)

        else:
            data = []
            for filename in glob.glob('Images/test/*.jpg'): 
                im = imread(filename)
                resized_image = imresize(im, (128, 128))
                if resized_image is not None:
                    data.append(resized_image)
            data = np.array(data)

        return data


class Places365Dataset(BaseDataset):
    def __init__(self, path, training=True, augment=True):
        super(Places365Dataset, self).__init__(PLACES365_DATASET, path, training, augment)

    def load(self):
        if self.training:
            data = np.array(
                glob.glob(self.path + '/data_256/**/*.jpg', recursive=True))

        else:
            data = np.array(glob.glob(self.path + '/val_256/*.jpg'))

        return data
